module.exports = {
  ssid: "your-ssid-here",
  tdid: "your-tdid-here"
};
