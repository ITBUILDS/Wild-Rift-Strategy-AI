module.exports = {
  use: "gemini", // or "openai"
  openaiKey: "sk-...",
  geminiKey: "GOOGLE_API_KEY"
};
