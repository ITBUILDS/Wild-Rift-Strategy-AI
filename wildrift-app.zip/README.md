# Wild Rift Companion App

This is a local Wild Rift preview app with:
- SSO login via Riot
- Skin preview store
- Mock inventory viewer

## Setup
1. Install dependencies: `npm install express passport passport-saml`
2. Run app: `node app.js`
3. Visit `http://localhost:3000`

Add your Riot session tokens to `config/tokens.js` to enable inventory preview.
