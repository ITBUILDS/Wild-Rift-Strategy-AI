const express = require('express');
const router = express.Router();
const tokens = require('../config/tokens');

router.get('/inventory', async (req, res) => {
  const ownedSkins = ['Yasuo - Battle Boss', 'Lux - Elementalist'];
  res.send(`<h2>🧾 My Skins</h2><ul>${
    ownedSkins.map(s => `<li>${s}</li>`).join('')
  }</ul>`);
});

module.exports = router;
