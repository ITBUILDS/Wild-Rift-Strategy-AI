const express = require('express');
const router = express.Router();
const config = require('../config/api');
const axios = require('axios');

router.post('/build', async (req, res) => {
  const prompt = req.body.prompt || "Suggest Wild Rift build for Yasuo Jungle";
  try {
    if (config.use === "openai") {
      const response = await axios.post("https://api.openai.com/v1/chat/completions", {
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }]
      }, {
        headers: { Authorization: `Bearer ${config.openaiKey}` }
      });
      res.json({ source: "openai", result: response.data.choices[0].message.content });
    } else {
      const response = await axios.post("https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent", {
        contents: [{ parts: [{ text: prompt }] }]
      }, {
        params: { key: config.geminiKey }
      });
      res.json({ source: "gemini", result: response.data.candidates[0].content.parts[0].text });
    }
  } catch (err) {
    res.status(500).json({ error: err.toString() });
  }
});

module.exports = router;
